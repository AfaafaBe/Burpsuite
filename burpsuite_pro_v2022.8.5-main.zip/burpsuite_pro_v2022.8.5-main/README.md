# Kali Linux BurpSuite_pro_v2022.8.5 with Permanent License key Installations: 

Link to latest burpsuite pro 2023.6.2 and soon: 

https://github.com/xiv3r/BurpSuite-Pro-Latest
                                                
# Auto install:
    git clone https://github.com/xiv3r/burpsuite_pro_v2022.8.5.git
    cd burpsuite_pro_v2022.8.5
    bash Install.sh



# Manual Key Setup:
     bash Burp.sh

Notes: Copy the license from loader to burpsuite > manual activation > copy burpsuite request key to loader request >  copy response to burpsuite paste key > voila!
     
https://github.com/xiv3r/burpsuite_pro_v2022.8.5/assets/117867334/f0b9ab66-500a-4ba8-af7e-3eed67a2cbe6


# RUN:
     Burp
